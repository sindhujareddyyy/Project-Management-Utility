export type TaskStatus = 'backlog' | 'todo' | 'in_progress' | 'in_review' | 'done';

export type TaskPriority = 'low' | 'medium' | 'high';

export type TaskType = 'feature' | 'bug' | 'chore' | 'documentation';

export interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  avatarColor: string;
}

export interface TaskHistoryItem {
  id: string;
  timestamp: string;
  type: 'create' | 'status_change' | 'update' | 'assignee_change';
  description: string;
  fieldChanged?: string;
  oldValue?: string;
  newValue?: string;
  userId?: string;
  userName?: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  status: TaskStatus;
  priority: TaskPriority;
  type: TaskType;
  assigneeId?: string;
  createdAt: string;
  updatedAt: string;
  category?: string;
  history: TaskHistoryItem[];
}
