import fs from 'fs';
import path from 'path';
import { Task, User, TaskHistoryItem, TaskStatus, TaskPriority, TaskType } from './types';

const DATA_DIR = path.join(process.cwd(), 'data');
const TASKS_FILE = path.join(DATA_DIR, 'tasks.json');
const USERS_FILE = path.join(DATA_DIR, 'users.json');

// Ensure data directory and files exist
function initDb() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  // Initial Seeding for Users
  if (!fs.existsSync(USERS_FILE)) {
    const initialUsers: User[] = [
      { id: 'u1', name: 'Alice Vance', email: 'alice.vance@example.com', role: 'Product Manager', avatarColor: 'bg-emerald-500' },
      { id: 'u2', name: 'Bob Chen', email: 'bob.chen@example.com', role: 'Backend Dev', avatarColor: 'bg-blue-500' },
      { id: 'u3', name: 'Diana Prince', email: 'diana.prince@example.com', role: 'Frontend Architect', avatarColor: 'bg-purple-500' },
      { id: 'u4', name: 'Bruce Wayne', email: 'bruce.wayne@example.com', role: 'QA Lead', avatarColor: 'bg-amber-500' },
    ];
    fs.writeFileSync(USERS_FILE, JSON.stringify(initialUsers, null, 2), 'utf-8');
  }

  // Initial Seeding for Tasks with rich history matching standard SDLC
  if (!fs.existsSync(TASKS_FILE)) {
    const initialTasks: Task[] = [
      {
        id: 't1',
        title: 'Design and Document User Authentication flow',
        description: 'Create detailed flowchart and sequence diagrams for JWT-based auth and social login integration.',
        status: 'done',
        priority: 'high',
        type: 'documentation',
        assigneeId: 'u1',
        createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(), // 5 days ago
        updatedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        category: 'Auth',
        history: [
          {
            id: 'h1_1',
            timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
            type: 'create',
            description: 'Task drafted & added to Agile Backlog as high-priority documentation.',
            userName: 'Alice Vance',
          },
          {
            id: 'h1_2',
            timestamp: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
            type: 'status_change',
            description: 'Moved task from Backlog to Todo.',
            fieldChanged: 'status',
            oldValue: 'backlog',
            newValue: 'todo',
            userName: 'Alice Vance',
          },
          {
            id: 'h1_3',
            timestamp: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
            type: 'assignee_change',
            description: 'Assigned task to Alice Vance.',
            fieldChanged: 'assigneeId',
            oldValue: 'unassigned',
            newValue: 'Alice Vance',
            userName: 'Alice Vance',
          },
          {
            id: 'h1_4',
            timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
            type: 'status_change',
            description: 'Completed documentation and diagram creation; marked as Done.',
            fieldChanged: 'status',
            oldValue: 'todo',
            newValue: 'done',
            userName: 'Alice Vance',
          },
        ],
      },
      {
        id: 't2',
        title: 'Bootstrap express backend with SQLite/JSON store',
        description: 'Set up basic routing, Express server, basic CORS, API key authorization, and mock database integration.',
        status: 'in_review',
        priority: 'high',
        type: 'feature',
        assigneeId: 'u2',
        createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 days ago
        updatedAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(), // 5 hours ago
        category: 'Backend',
        history: [
          {
            id: 'h2_1',
            timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
            type: 'create',
            description: 'Task initialized during sprint planning.',
            userName: 'Alice Vance',
          },
          {
            id: 'h2_2',
            timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
            type: 'assignee_change',
            description: 'Assigned to Bob Chen.',
            fieldChanged: 'assigneeId',
            oldValue: 'unassigned',
            newValue: 'Bob Chen',
            userName: 'Bob Chen',
          },
          {
            id: 'h2_3',
            timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
            type: 'status_change',
            description: 'Moved to In Progress. Initiated GitHub repository and starter project structures.',
            fieldChanged: 'status',
            oldValue: 'todo',
            newValue: 'in_progress',
            userName: 'Bob Chen',
          },
          {
            id: 'h2_4',
            timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
            type: 'status_change',
            description: 'Pushed draft routes and schema validations. Created PR and moved to In Review.',
            fieldChanged: 'status',
            oldValue: 'in_progress',
            newValue: 'in_review',
            userName: 'Bob Chen',
          },
        ],
      },
      {
        id: 't3',
        title: 'Design high-fidelity Agile Dashboard UI',
        description: 'Develop a modern, highly interactive Kanban/SDLC dashboard using Tailwind, supporting detailed task inspections.',
        status: 'in_progress',
        priority: 'medium',
        type: 'feature',
        assigneeId: 'u3',
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        category: 'Frontend',
        history: [
          {
            id: 'h3_1',
            timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
            type: 'create',
            description: 'Drafted front-end dashboard requirement.',
            userName: 'Alice Vance',
          },
          {
            id: 'h3_2',
            timestamp: new Date(Date.now() - 1.5 * 24 * 60 * 60 * 1000).toISOString(),
            type: 'assignee_change',
            description: 'Assigned to Diana Prince.',
            fieldChanged: 'assigneeId',
            oldValue: 'unassigned',
            newValue: 'Diana Prince',
            userName: 'Diana Prince',
          },
          {
            id: 'h3_3',
            timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
            type: 'status_change',
            description: 'Moved from Todo to In Progress. Started styling dashboard layouts with CSS variables.',
            fieldChanged: 'status',
            oldValue: 'todo',
            newValue: 'in_progress',
            userName: 'Diana Prince',
          },
        ],
      },
      {
        id: 't4',
        title: 'Formulate End-to-End Testing Suites',
        description: 'Define QA test suites for APIs and User creation forms. Ensure all CORS configuration edge cases are tested.',
        status: 'todo',
        priority: 'medium',
        type: 'chore',
        assigneeId: 'u4',
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        updatedAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
        category: 'QA',
        history: [
          {
            id: 'h4_1',
            timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
            type: 'create',
            description: 'Formed basic QA guidelines and stubbed task.',
            userName: 'Alice Vance',
          },
          {
            id: 'h4_2',
            timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
            type: 'assignee_change',
            description: 'Assigned to Bruce Wayne.',
            fieldChanged: 'assigneeId',
            oldValue: 'unassigned',
            newValue: 'Bruce Wayne',
            userName: 'Bruce Wayne',
          },
        ],
      },
      {
        id: 't5',
        title: 'Optimize Database Indexing & Caching',
        description: 'Implement key indexes for task statuses and active user references. Prepare caching layers for high traffic peaks.',
        status: 'backlog',
        priority: 'low',
        type: 'feature',
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        category: 'Database',
        history: [
          {
            id: 'h5_1',
            timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
            type: 'create',
            description: 'Drafted performance optimization backlog item for sprint 3.',
            userName: 'Alice Vance',
          },
        ],
      },
    ];
    fs.writeFileSync(TASKS_FILE, JSON.stringify(initialTasks, null, 2), 'utf-8');
  }
}

// Perform initialization immediately
initDb();

// Load helpers
export function getUsers(): User[] {
  try {
    initDb();
    const data = fs.readFileSync(USERS_FILE, 'utf-8');
    return JSON.parse(data) as User[];
  } catch (err) {
    console.error('Error reading users db', err);
    return [];
  }
}

export function saveUsers(users: User[]): void {
  try {
    initDb();
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing users db', err);
  }
}

export function getTasks(): Task[] {
  try {
    initDb();
    const data = fs.readFileSync(TASKS_FILE, 'utf-8');
    return JSON.parse(data) as Task[];
  } catch (err) {
    console.error('Error reading tasks db', err);
    return [];
  }
}

export function saveTasks(tasks: Task[]): void {
  try {
    initDb();
    fs.writeFileSync(TASKS_FILE, JSON.stringify(tasks, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing tasks db', err);
  }
}
