import React, { useState, useEffect } from 'react';
import { Task, User, TaskStatus, TaskPriority, TaskType } from './types';
import TaskCreator from './components/TaskCreator';
import UserManagement from './components/UserManagement';
import TaskHistoryTimeline from './components/TaskHistoryTimeline';
import InternshipCorner from './components/InternshipCorner';
import { 
  Projector, 
  Users, 
  Plus, 
  Search, 
  Filter, 
  HelpCircle, 
  Clock, 
  Settings, 
  UserCheck, 
  AlertCircle, 
  Kanban, 
  CheckSquare, 
  Laptop, 
  FileCode, 
  Trash2, 
  Edit3, 
  ChevronRight,
  ArrowRight,
  Calendar,
  Sparkles,
  GitPullRequest,
  CheckCircle2
} from 'lucide-react';

const API_KEY = 'pm-secret-token-123';

export default function App() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  
  // Current user simulator for actions/dashboards
  const [activeUser, setActiveUser] = useState<User | null>(null);
  
  // Search and filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [viewScope, setViewScope] = useState<'all' | 'assigned'>('all');

  // Modals / Overlays
  const [isTaskCreatorOpen, setIsTaskCreatorOpen] = useState(false);
  const [isUserManagementOpen, setIsUserManagementOpen] = useState(false);
  const [isInternshipCornerOpen, setIsInternshipCornerOpen] = useState(true);
  const [selectedTimelineTask, setSelectedTimelineTask] = useState<Task | null>(null);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  // Status alerts
  const [notification, setNotification] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  // Fetch initial tasks and users
  const refreshData = async () => {
    try {
      const usersRes = await fetch('/api/users');
      if (usersRes.ok) {
        const usersData = await usersRes.json();
        setUsers(usersData);
        if (usersData.length > 0 && !activeUser) {
          // Default active user simulate sign-in
          setActiveUser(usersData[0]);
        }
      }

      const tasksRes = await fetch('/api/tasks');
      if (tasksRes.ok) {
        const tasksData = await tasksRes.json();
        setTasks(tasksData);
      }
    } catch (err) {
      console.error('Error fetching data from Node API', err);
      showNotification('error', 'Failed to connect with live backend database.');
    }
  };

  useEffect(() => {
    refreshData();
  }, []);

  const showNotification = (type: 'success' | 'error', text: string) => {
    setNotification({ type, text });
    setTimeout(() => setNotification(null), 4000);
  };

  // Add a user
  const handleAddUser = async (newUserData: Omit<User, 'id'>) => {
    try {
      const res = await fetch(`/api/users?apiKey=${API_KEY}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newUserData),
      });

      if (res.ok) {
        const created = await res.json();
        setUsers(prev => [...prev, created]);
        showNotification('success', `Team profile created successfully for ${created.name}!`);
      } else {
        const err = await res.json();
        showNotification('error', err.error || 'Failed to enroll member.');
      }
    } catch {
      showNotification('error', 'Network failure during member creation.');
    }
  };

  // Delete a user
  const handleDeleteUser = async (userId: string) => {
    try {
      const res = await fetch(`/api/users/${userId}?apiKey=${API_KEY}`, {
        method: 'DELETE',
      });

      if (res.ok) {
        setUsers(prev => prev.filter(u => u.id !== userId));
        if (activeUser?.id === userId) {
          setActiveUser(null);
        }
        // Refresh tasks as some assignments might have been cleared by system
        const tasksRes = await fetch('/api/tasks');
        if (tasksRes.ok) {
          const tasksData = await tasksRes.json();
          setTasks(tasksData);
        }
        showNotification('success', 'User removed and corresponding active tasks unassigned.');
      } else {
        const err = await res.json();
        showNotification('error', err.error || 'Unable to delete user.');
      }
    } catch {
      showNotification('error', 'Network error during profile purging.');
    }
  };

  // Add a task
  const handleAddTask = async (newTaskData: {
    title: string;
    description: string;
    status: TaskStatus;
    priority: TaskPriority;
    type: TaskType;
    assigneeId?: string;
    category: string;
    authorName: string;
  }) => {
    try {
      const res = await fetch(`/api/tasks?apiKey=${API_KEY}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newTaskData),
      });

      if (res.ok) {
        const created = await res.json();
        setTasks(prev => [...prev, created]);
        showNotification('success', `Successfully initialized task "${created.title}"!`);
      } else {
        const err = await res.json();
        showNotification('error', err.error || 'Failed to initialize task.');
      }
    } catch {
      showNotification('error', 'Network connection state interrupted.');
    }
  };

  // Delete a task
  const handleDeleteTask = async (taskId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm('Are you sure you want to permanently delete this SDLC task? This cannot be undone.')) {
      return;
    }
    try {
      const res = await fetch(`/api/tasks/${taskId}?apiKey=${API_KEY}`, {
        method: 'DELETE',
      });

      if (res.ok) {
        setTasks(prev => prev.filter(t => t.id !== taskId));
        showNotification('success', 'Task has been safely purged from Sprint guidelines.');
      } else {
        const err = await res.json();
        showNotification('error', err.error || 'Failed to delete task.');
      }
    } catch {
      showNotification('error', 'Unable to reach backend endpoint.');
    }
  };

  // Update a task (e.g., Status change or General edit)
  const handleUpdateTask = async (taskId: string, updatedFields: Partial<Task>) => {
    try {
      const bodyPayload = {
        ...updatedFields,
        authorName: activeUser ? activeUser.name : 'System Monitor',
      };

      const res = await fetch(`/api/tasks/${taskId}?apiKey=${API_KEY}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bodyPayload),
      });

      if (res.ok) {
        const updatedTask = await res.json();
        setTasks(prev => prev.map(t => t.id === taskId ? updatedTask : t));
        if (selectedTimelineTask?.id === taskId) {
          setSelectedTimelineTask(updatedTask);
        }
        showNotification('success', `Task status ledger updated: "${updatedTask.title}"`);
      } else {
        const err = await res.json();
        showNotification('error', err.error || 'Unable to store status transitions.');
      }
    } catch {
      showNotification('error', 'Failure in recording state change.');
    }
  };

  // Handle task dragging simple column switchers
  const handleStatusTransition = async (taskId: string, targetStatus: TaskStatus) => {
    const taskObj = tasks.find(t => t.id === taskId);
    if (!taskObj) return;
    if (taskObj.status === targetStatus) return;

    await handleUpdateTask(taskId, { status: targetStatus });
  };

  // Handle 1-click seeding of professional project templates
  const handleSeedTemplate = async (templateName: string) => {
    try {
      const res = await fetch('/api/seed', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ template: templateName })
      });

      if (res.ok) {
        const data = await res.json();
        setUsers(data.users);
        setTasks(data.tasks);
        if (data.users.length > 0) {
          setActiveUser(data.users[0]);
        }
        showNotification('success', `Database primed with ${templateName.toUpperCase()} project metadata.`);
      } else {
        showNotification('error', 'Backend seeding transaction declined.');
      }
    } catch {
      showNotification('error', 'Network failure during pipeline seeding.');
    }
  };

  // Categories helper label
  const getPriorityBadgeStyle = (priority: TaskPriority) => {
    switch (priority) {
      case 'high':
        return 'bg-rose-50 border-rose-200 text-rose-700';
      case 'medium':
        return 'bg-amber-50 border-amber-200 text-amber-700';
      case 'low':
        return 'bg-emerald-50 border-emerald-200 text-emerald-700';
      default:
        return 'bg-slate-50 border-slate-200 text-slate-700';
    }
  };

  const getTypeIcon = (type: TaskType) => {
    switch (type) {
      case 'feature':
        return <Sparkles className="w-3.5 h-3.5 text-blue-500" />;
      case 'bug':
        return <AlertCircle className="w-3.5 h-3.5 text-rose-500" />;
      case 'chore':
        return <Settings className="w-3.5 h-3.5 text-slate-500" />;
      case 'documentation':
        return <FileCode className="w-3.5 h-3.5 text-indigo-500" />;
    }
  };

  // Filter tasks based on search & options
  const filteredTasks = tasks.filter(task => {
    const matchesSearch = 
      task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (task.category && task.category.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesPriority = selectedPriority === 'all' || task.priority === selectedPriority;
    const matchesType = selectedType === 'all' || task.type === selectedType;
    
    // View Scope: All vs Assigned to currently signed-in active profile
    const matchesScope = viewScope === 'all' || (activeUser && task.assigneeId === activeUser.id);

    return matchesSearch && matchesPriority && matchesType && matchesScope;
  });

  // Split tasks by SDLC phase
  const tasksByStatus: Record<TaskStatus, Task[]> = {
    backlog: filteredTasks.filter(t => t.status === 'backlog'),
    todo: filteredTasks.filter(t => t.status === 'todo'),
    in_progress: filteredTasks.filter(t => t.status === 'in_progress'),
    in_review: filteredTasks.filter(t => t.status === 'in_review'),
    done: filteredTasks.filter(t => t.status === 'done'),
  };

  const getAssigneeInfo = (assigneeId?: string) => {
    if (!assigneeId) return null;
    return users.find(u => u.id === assigneeId) || null;
  };

  return (
    <div className="flex h-screen w-screen bg-slate-50 font-sans text-slate-900 overflow-hidden" id="applet-viewport">
      {/* Sidebar Navigation */}
      <aside className="w-64 bg-slate-900 flex-shrink-0 flex flex-col justify-between border-r border-slate-850" id="sidebar-panel">
        <div>
          {/* Brand/Header */}
          <div className="p-6 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-600/20">
                <span className="text-white font-bold text-lg">P</span>
              </div>
              <div>
                <h1 className="text-white font-bold text-base tracking-tight leading-none">ProManager</h1>
                <span className="text-[10px] font-semibold text-slate-400 tracking-wider uppercase font-mono mt-0.5 inline-block">Agile Suite v2.4</span>
              </div>
            </div>
          </div>

          {/* Quick Stats Panel */}
          <div className="p-4 mx-4 my-3 bg-slate-850 rounded-xl border border-slate-800" id="sidebar-stats">
            <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono mb-2">Sprint Health</p>
            <div className="grid grid-cols-2 gap-2 text-center">
              <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                <span className="text-lg font-bold text-blue-400">{tasks.filter(t => t.status !== 'done').length}</span>
                <p className="text-[9px] text-slate-400 uppercase font-mono">Active</p>
              </div>
              <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                <span className="text-lg font-bold text-emerald-400">{tasks.filter(t => t.status === 'done').length}</span>
                <p className="text-[9px] text-slate-400 uppercase font-mono">Shipped</p>
              </div>
            </div>
          </div>

          {/* Nav Links */}
          <nav className="p-4 space-y-1.5" id="nav-list">
            <button 
              onClick={() => setViewScope('all')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg transition-all text-xs font-semibold cursor-pointer ${
                viewScope === 'all' 
                  ? 'bg-blue-600/10 text-blue-400 border border-blue-500/15' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Kanban className="w-4 h-4" />
                <span>Sprint SDLC Board</span>
              </div>
              <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-400 font-bold">{tasks.length}</span>
            </button>

            {activeUser && (
              <button 
                onClick={() => setViewScope('assigned')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg transition-all text-xs font-semibold cursor-pointer ${
                  viewScope === 'assigned' 
                    ? 'bg-blue-600/10 text-blue-400 border border-blue-500/15' 
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <UserCheck className="w-4 h-4" />
                  <span className="truncate max-w-[110px]">Assigned to Me</span>
                </div>
                <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-400 font-bold">
                  {tasks.filter(t => t.assigneeId === activeUser.id).length}
                </span>
              </button>
            )}

            <button 
              onClick={() => setIsUserManagementOpen(true)}
              className="w-full flex items-center gap-2.5 px-3 py-2.5 text-xs text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-all font-semibold text-left cursor-pointer"
              id="open-users-trigger"
            >
              <Users className="w-4 h-4" />
              <span>Manage Scrum Team</span>
            </button>

            <button 
              onClick={() => setIsInternshipCornerOpen(true)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg transition-all text-xs font-semibold cursor-pointer border ${
                isInternshipCornerOpen 
                  ? 'bg-blue-600/15 text-blue-400 border-blue-500/30 font-bold' 
                  : 'bg-emerald-950/25 text-emerald-400 border-emerald-900/35 hover:bg-emerald-950/40 hover:text-white'
              }`}
              id="open-internship-trigger"
            >
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
                <span>🎓 Portfolio Lab Panel</span>
              </div>
              <span className="text-[8px] bg-indigo-600 text-white font-mono px-2 py-0.5 rounded-full animate-bounce">Live</span>
            </button>
          </nav>
        </div>

        {/* User Account / Identity Switcher */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/40">
          <p className="text-[9px] font-bold uppercase tracking-wider text-slate-500 font-mono mb-2">Simulate Team Persona</p>
          {users.length > 0 ? (
            <div className="relative">
              <select
                value={activeUser?.id || ''}
                onChange={(e) => {
                  const found = users.find(u => u.id === e.target.value);
                  if (found) setActiveUser(found);
                }}
                className="w-full bg-slate-800 text-white text-xs py-2 px-2.5 rounded-lg border border-slate-700/60 focus:outline-none focus:ring-1 focus:ring-blue-500 font-medium truncate"
                id="persona-selector"
              >
                {users.map((u) => (
                  <option key={u.id} value={u.id}>
                    👤 {u.name} ({u.role})
                  </option>
                ))}
              </select>
            </div>
          ) : (
            <div className="text-[10px] text-slate-500 italic">No team users registered. Modify members inside Scrum Team.</div>
          )}
        </div>
      </aside>

      {/* Main Content Area */}
      <main className={`flex-1 flex flex-col min-w-0 overflow-hidden transition-all duration-300 ${isInternshipCornerOpen ? 'mr-[480px]' : ''}`} id="main-canvas">
        {/* API Toast alerts */}
        {notification && (
          <div 
            className={`fixed top-4 right-4 z-50 p-3.5 rounded-xl shadow-lg border text-xs font-semibold flex items-center gap-2 animate-bounce ${
              notification.type === 'success' 
                ? 'bg-emerald-50 border-emerald-200 text-emerald-800 shadow-emerald-100' 
                : 'bg-rose-50 border-rose-200 text-rose-800 shadow-rose-100'
            }`}
            id="toast-notification"
          >
            <div className={`w-2 h-2 rounded-full ${notification.type === 'success' ? 'bg-emerald-500' : 'bg-rose-500'}`} />
            <span>{notification.text}</span>
          </div>
        )}

        {/* Global Toolbar Header */}
        <header className="h-16 bg-white border-b border-slate-200 px-8 flex items-center justify-between flex-shrink-0" id="header-toolbar">
          <div className="flex items-center gap-3">
            <span className="text-slate-400 text-xs font-mono font-bold uppercase tracking-wider">PROJECT CORNER /</span>
            <h2 className="text-base font-bold text-slate-800 flex items-center gap-2">
              Sprint 24 Board 
              <span className="bg-blue-50 text-blue-600 text-[10px] uppercase font-bold tracking-wide px-2 py-0.5 rounded border border-blue-100">SDLC Agile</span>
            </h2>
          </div>

          <div className="flex items-center gap-3">
            {/* Quick stats totals */}
            <div className="hidden lg:flex items-center gap-4 text-xs font-mono text-slate-500 mr-2 border-r border-slate-200 pr-5">
              <span>Backlog: <strong className="text-slate-700">{filteredTasks.filter(t => t.status === 'backlog').length}</strong></span>
              <span>Test Suite: <strong className="text-slate-700">{filteredTasks.filter(t => t.status === 'in_review').length}</strong></span>
              <span>Done: <strong className="text-slate-700">{filteredTasks.filter(t => t.status === 'done').length}</strong></span>
            </div>

            <button 
              onClick={() => setIsTaskCreatorOpen(true)}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg transition-colors shadow-sm shadow-blue-500/10 cursor-pointer flex items-center gap-1.5"
              id="new-task-trigger"
            >
              <Plus className="w-4 h-4" />
              New Task Definition
            </button>
          </div>
        </header>

        {/* Search, Grouping and Filters Shelf */}
        <div className="bg-white border-b border-slate-200 px-8 py-3.5 flex flex-wrap items-center justify-between gap-4 flex-shrink-0" id="filter-shelf">
          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            {/* Search Input */}
            <div className="relative w-full max-w-[280px]">
              <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search tasks or components..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>

            {/* Severity Priority Filter */}
            <div className="flex items-center gap-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wide font-mono mr-1">Severity:</span>
              <select
                value={selectedPriority}
                onChange={(e) => setSelectedPriority(e.target.value)}
                className="bg-white border border-slate-200 text-xs px-2 py-1 rounded-md text-slate-600 focus:ring-1 focus:ring-blue-500"
              >
                <option value="all">⚡ All Severities</option>
                <option value="high">🔴 High</option>
                <option value="medium">🟡 Medium</option>
                <option value="low">🟢 Low</option>
              </select>
            </div>

            {/* Work Type Filter */}
            <div className="flex items-center gap-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wide font-mono mr-1">Issue Type:</span>
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="bg-white border border-slate-200 text-xs px-2 py-1 rounded-md text-slate-600 focus:ring-1 focus:ring-blue-500"
              >
                <option value="all">🛠️ All Issue Types</option>
                <option value="feature">✨ Feature Spec</option>
                <option value="bug">🐛 Defect Fix</option>
                <option value="chore">🧹 Chore/Refactor</option>
                <option value="documentation">📚 Docs</option>
              </select>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {filteredTasks.length !== tasks.length && (
              <button 
                onClick={() => {
                  setSearchQuery('');
                  setSelectedPriority('all');
                  setSelectedType('all');
                  setViewScope('all');
                }}
                className="text-[10px] font-bold text-blue-600 hover:text-blue-800 bg-blue-50 px-2.5 py-1 rounded border border-blue-100 hover:bg-blue-100 transition-colors"
              >
                Reset Filters ({filteredTasks.length} shown)
              </button>
            )}
          </div>
        </div>

        {/* SDLC Kanban Board Columns Container */}
        <div className="flex-1 overflow-x-auto overflow-y-hidden bg-slate-50 p-6 flex gap-6" id="board-columns-slider">
          {/* Column 1: Backlog */}
          <div className="flex-1 min-w-[280px] max-w-[320px] flex flex-col h-full bg-slate-100/50 rounded-xl border border-slate-200/50 p-4" id="col-backlog">
            <div className="flex items-center justify-between mb-3 flex-shrink-0">
              <div className="flex items-center gap-2">
                <span className="bg-slate-200 text-slate-600 text-[10.5px] font-mono font-bold px-2 py-0.5 rounded">
                  01
                </span>
                <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider font-mono">Agile Backlog</h3>
              </div>
              <span className="bg-slate-200 text-slate-600 text-[10px] font-mono font-bold px-2 py-0.2 rounded-full">
                {tasksByStatus.backlog.length}
              </span>
            </div>
            
            {/* Task list container */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1" id="list-backlog">
              {tasksByStatus.backlog.map(task => renderTaskCard(task))}
              {tasksByStatus.backlog.length === 0 && renderEmptyColumnPlaceholder('backlog')}
            </div>
          </div>

          {/* Column 2: To Do */}
          <div className="flex-1 min-w-[280px] max-w-[320px] flex flex-col h-full bg-slate-100/50 rounded-xl border border-slate-200/50 p-4" id="col-todo">
            <div className="flex items-center justify-between mb-3 flex-shrink-0">
              <div className="flex items-center gap-2">
                <span className="bg-indigo-100 text-indigo-700 text-[10.5px] font-mono font-bold px-2 py-0.5 rounded border border-indigo-200/30">
                  02
                </span>
                <h3 className="text-xs font-bold text-indigo-800 uppercase tracking-wider font-mono">Scope Todo</h3>
              </div>
              <span className="bg-slate-200 text-slate-600 text-[10px] font-mono font-bold px-2 py-0.2 rounded-full">
                {tasksByStatus.todo.length}
              </span>
            </div>
            
            {/* Task list container */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1" id="list-todo">
              {tasksByStatus.todo.map(task => renderTaskCard(task))}
              {tasksByStatus.todo.length === 0 && renderEmptyColumnPlaceholder('todo')}
            </div>
          </div>

          {/* Column 3: In Progress */}
          <div className="flex-1 min-w-[280px] max-w-[320px] flex flex-col h-full bg-slate-100/50 rounded-xl border border-slate-200/50 p-4" id="col-progress">
            <div className="flex items-center justify-between mb-3 flex-shrink-0">
              <div className="flex items-center gap-2">
                <span className="bg-blue-100 text-blue-700 text-[10.5px] font-mono font-bold px-2 py-0.5 rounded border border-blue-200/30">
                  03
                </span>
                <h3 className="text-xs font-bold text-blue-800 uppercase tracking-wider font-mono">Development</h3>
              </div>
              <span className="bg-blue-100 text-blue-600 text-[10px] font-mono font-bold px-2 py-0.2 rounded-full">
                {tasksByStatus.in_progress.length}
              </span>
            </div>
            
            {/* Task list container */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1" id="list-progress">
              {tasksByStatus.in_progress.map(task => renderTaskCard(task))}
              {tasksByStatus.in_progress.length === 0 && renderEmptyColumnPlaceholder('in_progress')}
            </div>
          </div>

          {/* Column 4: In Review / QA */}
          <div className="flex-1 min-w-[280px] max-w-[320px] flex flex-col h-full bg-slate-100/50 rounded-xl border border-slate-200/50 p-4" id="col-review">
            <div className="flex items-center justify-between mb-3 flex-shrink-0">
              <div className="flex items-center gap-2">
                <span className="bg-amber-100 text-amber-700 text-[10.5px] font-mono font-bold px-2 py-0.5 rounded border border-amber-200/30">
                  04
                </span>
                <h3 className="text-xs font-bold text-amber-800 uppercase tracking-wider font-mono">Quality Assurance</h3>
              </div>
              <span className="bg-amber-100 text-amber-600 text-[10px] font-mono font-bold px-2 py-0.2 rounded-full">
                {tasksByStatus.in_review.length}
              </span>
            </div>
            
            {/* Task list container */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1" id="list-review">
              {tasksByStatus.in_review.map(task => renderTaskCard(task))}
              {tasksByStatus.in_review.length === 0 && renderEmptyColumnPlaceholder('in_review')}
            </div>
          </div>

          {/* Column 5: Deployed / Done */}
          <div className="flex-1 min-w-[280px] max-w-[320px] flex flex-col h-full bg-slate-100/50 rounded-xl border border-slate-200/50 p-4" id="col-done">
            <div className="flex items-center justify-between mb-3 flex-shrink-0">
              <div className="flex items-center gap-2">
                <span className="bg-emerald-100 text-emerald-700 text-[10.5px] font-mono font-bold px-2 py-0.5 rounded border border-emerald-200/30">
                  05
                </span>
                <h3 className="text-xs font-bold text-emerald-800 uppercase tracking-wider font-mono">Deployed</h3>
              </div>
              <span className="bg-emerald-100 text-emerald-600 text-[10px] font-mono font-bold px-2 py-0.2 rounded-full">
                {tasksByStatus.done.length}
              </span>
            </div>
            
            {/* Task list container */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1" id="list-done">
              {tasksByStatus.done.map(task => renderTaskCard(task))}
              {tasksByStatus.done.length === 0 && renderEmptyColumnPlaceholder('done')}
            </div>
          </div>
        </div>
      </main>

      {/* Interactive Modal popups */}
      {isTaskCreatorOpen && (
        <TaskCreator
          users={users}
          onAddTask={handleAddTask}
          onClose={() => setIsTaskCreatorOpen(false)}
        />
      )}

      {isUserManagementOpen && (
        <UserManagement
          users={users}
          onAddUser={handleAddUser}
          onDeleteUser={handleDeleteUser}
          onClose={() => setIsUserManagementOpen(false)}
        />
      )}

      {selectedTimelineTask && (
        <TaskHistoryTimeline
          task={selectedTimelineTask}
          onClose={() => setSelectedTimelineTask(null)}
        />
      )}

      {editingTask && renderTaskEditModal()}

      {isInternshipCornerOpen && (
        <InternshipCorner
          tasks={tasks}
          users={users}
          onSeedTemplate={handleSeedTemplate}
          onClose={() => setIsInternshipCornerOpen(false)}
        />
      )}
    </div>
  );

  // Reusable task card renderer to match Professional Polish design spec
  function renderTaskCard(task: Task) {
    const assignee = getAssigneeInfo(task.assigneeId);
    
    // Determine card level border accent based on status / active priority styling
    const borderLeftColor = task.priority === 'high' 
      ? 'border-l-rose-500' 
      : task.priority === 'medium' 
        ? 'border-l-amber-500' 
        : 'border-l-emerald-500';

    return (
      <div 
        key={task.id}
        onClick={() => setSelectedTimelineTask(task)}
        className={`bg-white p-4 rounded-xl border border-slate-200 shadow-xs hover:shadow-md cursor-pointer transition-all border-l-4 ${borderLeftColor} hover:-translate-y-0.5 select-none relative group`}
        id={`task-card-${task.id}`}
      >
        {/* Header line: Category label + Issue type indicator */}
        <div className="flex items-center justify-between gap-2 mb-2">
          <span className="text-[10px] font-mono font-extrabold uppercase tracking-wider text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
            {task.category || 'General'}
          </span>
          <div className="flex items-center gap-1.5">
            {getTypeIcon(task.type)}
            <span className="text-[10px] font-medium text-slate-500 uppercase">{task.type}</span>
          </div>
        </div>

        {/* Task Title */}
        <h4 className="text-xs font-bold text-slate-800 line-clamp-2 leading-snug group-hover:text-blue-600 transition-colors">
          {task.title}
        </h4>

        {/* Task desc preview */}
        {task.description && (
          <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed mt-1.5">
            {task.description}
          </p>
        )}

        {/* Middle Line containing Priority status + phase quick jump arrow */}
        <div className="flex items-center justify-between mt-3.5 pt-3.5 border-t border-slate-100">
          <div className="flex items-center gap-1.5">
            <span className={`text-[9px] font-mono font-extrabold uppercase tracking-tight px-1.5 py-0.5 rounded border ${getPriorityBadgeStyle(task.priority)}`}>
              {task.priority}
            </span>
          </div>

          {/* Quick jump timeline phase action indicator */}
          <div className="flex items-center gap-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setEditingTask(task);
              }}
              title="Edit properties/status"
              className="p-1 text-slate-400 hover:text-blue-600 hover:bg-slate-100 rounded transition-all"
            >
              <Edit3 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={(e) => handleDeleteTask(task.id, e)}
              title="Purge task"
              className="p-1 text-slate-400 hover:text-rose-600 hover:bg-slate-100 rounded transition-all"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Assignee display */}
        <div className="flex items-center justify-between mt-2.5">
          <div className="text-[10px] font-mono text-slate-400 flex items-center gap-1">
            <Clock className="w-3 h-3 text-slate-300" />
            <span>Updated {new Date(task.updatedAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</span>
          </div>

          {assignee ? (
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] text-slate-600 font-medium truncate max-w-[80px]" title={assignee.name}>
                {assignee.name.split(' ')[0]}
              </span>
              <div className={`w-5 h-5 rounded-full ${assignee.avatarColor} flex items-center justify-center text-white font-bold text-[8px]`} title={`${assignee.name} (${assignee.role})`}>
                {assignee.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
              </div>
            </div>
          ) : (
            <span className="text-[9px] font-mono font-bold text-slate-300 italic">Unassigned</span>
          )}
        </div>

        {/* Quick jump phase buttons on hover */}
        <div className="hidden group-hover:flex absolute -top-2.5 right-2 bg-white rounded-full border border-slate-200 shadow-sm px-2 py-0.5 items-center gap-1 animate-fade-in text-[9px] font-bold text-slate-500">
          <span>Sprint Stage: {task.status.replace('_', ' ').toUpperCase()}</span>
        </div>
      </div>
    );
  }

  // Placeholder for empty Board Status Column
  function renderEmptyColumnPlaceholder(colStatus: TaskStatus) {
    let message = 'No active components';
    switch (colStatus) {
      case 'backlog':
        message = 'Agile backlog clear';
        break;
      case 'todo':
        message = 'Todo list prioritized';
        break;
      case 'in_progress':
        message = 'Under review / quiet';
        break;
      case 'in_review':
        message = 'Code analysis verified';
        break;
      case 'done':
        message = 'Waiting build release';
        break;
    }
    return (
      <div 
        className="border-2 border-dashed border-slate-200/60 rounded-xl py-12 px-4 text-center cursor-default" 
        id={`empty-col-${colStatus}`}
      >
        <CheckSquare className="w-8 h-8 stroke-1 mx-auto text-slate-350 mb-2" />
        <span className="text-slate-400 text-xs italic font-sans">{message}</span>
      </div>
    );
  }

  // Quick Inline Task Edit dialog
  function renderTaskEditModal() {
    if (!editingTask) return null;
    return (
      <div 
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4"
        onClick={() => setEditingTask(null)}
      >
        <div 
          className="bg-white rounded-xl shadow-xl border border-slate-100 max-w-sm w-full p-6 space-y-4"
          onClick={(e) => e.stopPropagation()}
        >
          <div>
            <span className="text-[10px] font-mono font-bold text-blue-600 bg-blue-50 px-2.5 py-0.5 rounded border border-blue-100 uppercase tracking-wider">
              Lead Workflow Desk
            </span>
            <h3 className="text-sm font-bold text-slate-900 mt-2 line-clamp-2">{editingTask.title}</h3>
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 font-mono">SDLC Phase State</label>
              <select
                value={editingTask.status}
                onChange={(e) => {
                  const val = e.target.value as TaskStatus;
                  setEditingTask(prev => prev ? { ...prev, status: val } : null);
                }}
                className="w-full bg-slate-50 border border-slate-200 text-xs rounded-lg p-2 font-mono font-semibold text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
              >
                <option value="backlog">🗄️ BACKLOG</option>
                <option value="todo">📋 TO DO</option>
                <option value="in_progress">⚙️ IN PROGRESS</option>
                <option value="in_review">🔍 QA / IN REVIEW</option>
                <option value="done">✅ DEPLOYED / DONE</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 font-mono">Assign Tech lead</label>
              <select
                value={editingTask.assigneeId || ''}
                onChange={(e) => {
                  const val = e.target.value || undefined;
                  setEditingTask(prev => prev ? { ...prev, assigneeId: val } : null);
                }}
                className="w-full bg-slate-50 border border-slate-200 text-xs rounded-lg p-2 text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
              >
                <option value="">Unassigned</option>
                {users.map(u => (
                  <option key={u.id} value={u.id}>{u.name} ({u.role})</option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 font-mono">Severity</label>
                <select
                  value={editingTask.priority}
                  onChange={(e) => {
                    const val = e.target.value as TaskPriority;
                    setEditingTask(prev => prev ? { ...prev, priority: val } : null);
                  }}
                  className="w-full bg-slate-50 border border-slate-200 text-xs rounded-lg p-2 text-slate-700 font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500"
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 font-mono">Issue Type</label>
                <select
                  value={editingTask.type}
                  onChange={(e) => {
                    const val = e.target.value as TaskType;
                    setEditingTask(prev => prev ? { ...prev, type: val } : null);
                  }}
                  className="w-full bg-slate-50 border border-slate-200 text-xs rounded-lg p-2 text-slate-700 font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500"
                >
                  <option value="feature">Feature</option>
                  <option value="bug">Bug Fix</option>
                  <option value="chore">Chore</option>
                  <option value="documentation">Docs</option>
                </select>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 bg-slate-50 -mx-6 -mb-6 p-4 rounded-b-xl">
            <button
              onClick={() => setEditingTask(null)}
              className="px-3.5 py-1.5 border border-slate-200 text-xs font-semibold rounded-lg text-slate-500 hover:bg-slate-100 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                if (editingTask) {
                  handleUpdateTask(editingTask.id, {
                    status: editingTask.status,
                    assigneeId: editingTask.assigneeId,
                    priority: editingTask.priority,
                    type: editingTask.type
                  });
                  setEditingTask(null);
                }
              }}
              className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg transition-colors shadow-sm"
            >
              Commit Changes
            </button>
          </div>
        </div>
      </div>
    );
  }
}
