import React from 'react';
import { Task, TaskHistoryItem } from '../types';
import { Clock, User, ArrowRight, CheckCircle2, AlertTriangle, FileText, Plus, X } from 'lucide-react';

interface TaskHistoryTimelineProps {
  task: Task;
  onClose: () => void;
}

export default function TaskHistoryTimeline({ task, onClose }: TaskHistoryTimelineProps) {
  // Sort history chronologically (newest first)
  const sortedHistory = [...task.history].sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  const getIcon = (type: string) => {
    switch (type) {
      case 'create':
        return <Plus className="w-5 h-5 text-emerald-500" />;
      case 'status_change':
        return <ArrowRight className="w-5 h-5 text-blue-500" />;
      case 'assignee_change':
        return <User className="w-5 h-5 text-purple-500" />;
      default:
        return <FileText className="w-5 h-5 text-slate-500" />;
    }
  };

  const getBadgeColor = (type: string) => {
    switch (type) {
      case 'create':
        return 'bg-emerald-50 border-emerald-200 text-emerald-700';
      case 'status_change':
        return 'bg-blue-50 border-blue-200 text-blue-700';
      case 'assignee_change':
        return 'bg-purple-50 border-purple-200 text-purple-700';
      default:
        return 'bg-slate-50 border-slate-200 text-slate-700';
    }
  };

  const formatTime = (isoString: string) => {
    try {
      const date = new Date(isoString);
      return date.toLocaleString('en-US', {
        month: 'short',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return isoString;
    }
  };

  const formatPhaseLabel = (phase: string) => {
    if (!phase) return '';
    return phase.replace('_', ' ').toUpperCase();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in" id="history-modal-overlay">
      <div 
        className="bg-white rounded-xl shadow-xl border border-slate-100 max-w-lg w-full max-h-[85vh] flex flex-col"
        id="history-modal-container"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50 rounded-t-xl" id="history-header">
          <div>
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-sm border border-indigo-100 mb-1 inline-block">
              Task SDLC Audit Log
            </span>
            <h3 className="text-base font-semibold text-slate-900 line-clamp-1">{task.title}</h3>
            <p className="text-xs text-slate-500 mt-0.5">Task ID: {task.id}</p>
          </div>
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 hover:bg-slate-100 p-1.5 rounded-lg transition-colors cursor-pointer"
            id="close-history-btn"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Contents */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6" id="history-list-container">
          <div className="relative border-l-2 border-slate-150 pl-6 ml-3 space-y-6">
            {sortedHistory.map((item, idx) => (
              <div key={item.id || idx} className="relative group" id={`history-item-${idx}`}>
                {/* Timeline dot icon placement */}
                <div className="absolute -left-[37px] top-1 bg-white p-1 rounded-full border border-slate-200 shadow-sm transition-transform group-hover:scale-105">
                  {getIcon(item.type)}
                </div>

                {/* Timeline Card details */}
                <div className="bg-slate-50 hover:bg-slate-100/70 border border-slate-100 p-3.5 rounded-lg transition-all">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded border ${getBadgeColor(item.type)}`}>
                      {item.type.toUpperCase()}
                    </span>
                    <span className="text-[11px] font-mono text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {formatTime(item.timestamp)}
                    </span>
                  </div>

                  <p className="text-sm text-slate-700 leading-relaxed font-sans mt-1">
                    {item.description}
                  </p>

                  {/* Transition path visualization if status changed */}
                  {item.fieldChanged === 'status' && item.oldValue && item.newValue && (
                    <div className="mt-2 flex items-center gap-2 bg-white px-2.5 py-1.5 rounded border border-slate-200/60 max-w-max">
                      <span className="text-[10px] font-mono font-bold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                        {formatPhaseLabel(item.oldValue)}
                      </span>
                      <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                      <span className="text-[10px] font-mono font-bold text-blue-600 bg-blue-50 border border-blue-100 px-1.5 py-0.5 rounded">
                        {formatPhaseLabel(item.newValue)}
                      </span>
                    </div>
                  )}

                  <div className="mt-2 flex items-center justify-end text-xs text-slate-500">
                    <span className="font-medium text-slate-600 flex items-center gap-1 bg-white px-1.5 py-0.5 rounded border border-slate-150">
                      <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full inline-block"></span>
                      By {item.userName || 'System'}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {sortedHistory.length === 0 && (
            <div className="text-center py-12 text-slate-400 font-sans" id="history-empty">
              <Clock className="w-12 h-12 stroke-1 mx-auto text-slate-200 mb-2" />
              <p className="text-sm">No transition history logs recorded yet.</p>
            </div>
          )}
        </div>

        {/* Footer info banner */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 text-[11px] font-mono text-slate-500 text-center rounded-b-xl" id="history-footer">
          Trace recorded permanently via internal document ledger.
        </div>
      </div>
    </div>
  );
}
