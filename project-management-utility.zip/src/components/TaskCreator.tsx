import React, { useState } from 'react';
import { User, TaskStatus, TaskPriority, TaskType } from '../types';
import { Plus, X, ListCollapse, ChevronRight, HelpCircle } from 'lucide-react';

interface TaskCreatorProps {
  users: User[];
  onAddTask: (task: {
    title: string;
    description: string;
    status: TaskStatus;
    priority: TaskPriority;
    type: TaskType;
    assigneeId?: string;
    category: string;
    authorName: string;
  }) => void;
  onClose: () => void;
}

export default function TaskCreator({ users, onAddTask, onClose }: TaskCreatorProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState<TaskStatus>('todo');
  const [priority, setPriority] = useState<TaskPriority>('medium');
  const [type, setType] = useState<TaskType>('feature');
  const [assigneeId, setAssigneeId] = useState('');
  const [category, setCategory] = useState('Frontend');
  const [authorName, setAuthorName] = useState('Alice Vance'); // default author

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onAddTask({
      title: title.trim(),
      description: description.trim(),
      status,
      priority,
      type,
      assigneeId: assigneeId || undefined,
      category: category.trim(),
      authorName: authorName.trim() || 'Project Lead',
    });

    onClose();
  };

  const CATEGORIES = ['Frontend', 'Backend', 'Database', 'Auth', 'QA', 'DevOps', 'Design', 'General'];

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in" id="task-creator-overlay">
      <div 
        className="bg-white rounded-xl shadow-xl border border-slate-100 max-w-lg w-full max-h-[90vh] flex flex-col"
        id="task-creator-container"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50 rounded-t-xl" id="creator-header">
          <div className="flex items-center gap-2">
            <ListCollapse className="w-5 h-5 text-indigo-500" />
            <h3 className="text-base font-semibold text-slate-900">Task Definition Creator</h3>
          </div>
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 hover:bg-slate-100 p-1.5 rounded-lg transition-colors cursor-pointer"
            id="close-task-creator-btn"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Contents */}
        <form onSubmit={handleSubmit} className="flex flex-col flex-1 overflow-hidden">
          <div className="p-6 space-y-4 overflow-y-auto flex-1">
            {/* Task Title */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1 font-sans">Task Summary / Title</label>
              <input
                type="text"
                placeholder="e.g. Implement server-side JWT verification route"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                required
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1 font-sans">Scope Details (Optional)</label>
              <textarea
                placeholder="Describe acceptance criteria, technical details or documentation links..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500 resize-none"
              />
            </div>

            {/* Status Grid & Category */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1 font-sans">SDLC Target Phase</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as TaskStatus)}
                  className="w-full px-2.5 py-2 border border-slate-200 rounded-lg text-xs bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
                >
                  <option value="backlog">🗄️ BACKLOG</option>
                  <option value="todo">📋 TO DO</option>
                  <option value="in_progress">⚙️ IN PROGRESS</option>
                  <option value="in_review">🔍 IN REVIEW/TEST</option>
                  <option value="done">✅ DONE / DELIVERED</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1 font-sans">SDLC Component Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-2.5 py-2 border border-slate-200 rounded-lg text-xs bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  {CATEGORIES.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Priority & Type */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1 font-sans">Severity/Priority</label>
                <div className="flex gap-1.5 bg-slate-50 p-1 rounded-lg border border-slate-200/50">
                  {(['low', 'medium', 'high'] as TaskPriority[]).map((p) => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setPriority(p)}
                      className={`flex-1 text-[10px] uppercase font-bold py-1 px-1.5 rounded-md transition-all cursor-pointer ${
                        priority === p 
                          ? p === 'high' ? 'bg-rose-500 text-white shadow-xs' : p === 'medium' ? 'bg-amber-500 text-white shadow-xs' : 'bg-emerald-500 text-white shadow-xs'
                          : 'text-slate-400 hover:text-slate-700 hover:bg-slate-200/50'
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1 font-sans">Issue / Work Type</label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value as TaskType)}
                  className="w-full px-2.5 py-2 border border-slate-200 rounded-lg text-xs bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500 uppercase font-bold text-slate-700"
                >
                  <option value="feature">✨ Feature</option>
                  <option value="bug">🐛 Bug Fix</option>
                  <option value="chore">🧹 Chore/Refactor</option>
                  <option value="documentation">📚 Docs</option>
                </select>
              </div>
            </div>

            {/* Assignee Selection */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1 font-sans">Sprint Assignee</label>
              <select
                value={assigneeId}
                onChange={(e) => setAssigneeId(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="">Unassigned (Open Backlog)</option>
                {users.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name} — {u.role}
                  </option>
                ))}
              </select>
            </div>

            {/* Author Attribution */}
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-150">
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1 font-mono">
                Attribution (Created By)
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Your Name (e.g. Alice Vance)"
                  value={authorName}
                  onChange={(e) => setAuthorName(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  required
                />
              </div>
              <p className="text-[10px] text-slate-400 mt-1.5 leading-tight">
                This identity will be appended to the permanent audit ledger for this task.
              </p>
            </div>
          </div>

          {/* Form Footer Action */}
          <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-end gap-2" id="creator-footer">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-200 rounded-lg text-xs font-semibold text-slate-500 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold transition-all shadow-xs hover:shadow-sm cursor-pointer flex items-center gap-1"
            >
              <Plus className="w-4 h-4" />
              Initialize Task
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
