import React, { useState } from 'react';
import { User } from '../types';
import { Users, Mail, Trash2, Plus, X, ShieldAlert } from 'lucide-react';

interface UserManagementProps {
  users: User[];
  onAddUser: (user: Omit<User, 'id'>) => void;
  onDeleteUser: (userId: string) => void;
  onClose: () => void;
}

const AVATAR_COLORS = [
  { class: 'bg-emerald-500', name: 'Emerald' },
  { class: 'bg-blue-500', name: 'Ocean' },
  { class: 'bg-purple-500', name: 'Amethyst' },
  { class: 'bg-amber-500', name: 'Amber' },
  { class: 'bg-rose-500', name: 'Rose' },
  { class: 'bg-indigo-500', name: 'Indigo' },
  { class: 'bg-pink-500', name: 'Blush' },
];

export default function UserManagement({ users, onAddUser, onDeleteUser, onClose }: UserManagementProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('Developer');
  const [avatarColor, setAvatarColor] = useState('bg-blue-500');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!name.trim() || !email.trim()) {
      setErrorMsg('Please specify both Name and Email.');
      return;
    }

    if (!email.includes('@') || !email.includes('.')) {
      setErrorMsg('Please supply a valid email address.');
      return;
    }

    onAddUser({
      name: name.trim(),
      email: email.trim(),
      role,
      avatarColor,
    });

    // Reset Form
    setName('');
    setEmail('');
    setRole('Developer');
    setAvatarColor('bg-blue-500');
  };

  const getInitials = (nameStr: string) => {
    return nameStr
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in" id="user-management-overlay">
      <div 
        className="bg-white rounded-xl shadow-xl border border-slate-100 max-w-2xl w-full max-h-[85vh] flex flex-col"
        id="user-management-container"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50 rounded-t-xl" id="user-header">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-500" />
            <h3 className="text-base font-semibold text-slate-900">Manage Team Members</h3>
          </div>
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 hover:bg-slate-100 p-1.5 rounded-lg transition-colors cursor-pointer"
            id="close-user-management-btn"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form and List Grid */}
        <div className="p-6 overflow-y-auto flex-1 grid grid-cols-1 md:grid-cols-12 gap-6" id="user-grid">
          {/* Add User Form */}
          <div className="md:col-span-5 border-b md:border-b-0 md:border-r border-slate-100 pb-6 md:pb-0 md:pr-6" id="add-user-cohort">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4 font-mono">Create Profile</h4>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              {errorMsg && (
                <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 flex-shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1 font-sans">Full Name</label>
                <input
                  type="text"
                  placeholder="e.g. John Doe"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1 font-sans">Email</label>
                <input
                  type="email"
                  placeholder="e.g. john@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1 font-sans">SDLC Role</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  <option value="Product Manager">Product Manager</option>
                  <option value="Lead Architect">Lead Architect</option>
                  <option value="Frontend Dev">Frontend Dev</option>
                  <option value="Backend Dev">Backend Dev</option>
                  <option value="QA Engineer">QA Engineer</option>
                  <option value="UX Designer">UX Designer</option>
                  <option value="DevOps Specialist">DevOps Specialist</option>
                </select>
              </div>

              {/* Avatar Color selector */}
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5 font-sans">Avatar Color Accent</label>
                <div className="flex flex-wrap gap-2">
                  {AVATAR_COLORS.map((color) => (
                    <button
                      key={color.class}
                      type="button"
                      onClick={() => setAvatarColor(color.class)}
                      aria-label={color.name}
                      className={`w-6 h-6 rounded-full ${color.class} border-2 ${
                        avatarColor === color.class ? 'border-indigo-600 scale-110 shadow-sm' : 'border-transparent hover:scale-105'
                      } cursor-pointer transition-transform`}
                    />
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 px-4 rounded-lg text-sm font-medium transition-colors shadow-xs hover:shadow-sm cursor-pointer flex items-center justify-center gap-1.5 mt-2"
              >
                <Plus className="w-4 h-4" />
                Add Member
              </button>
            </form>
          </div>

          {/* User List Panel */}
          <div className="md:col-span-7 flex flex-col max-h-[50vh] md:max-h-full" id="user-registry-cohort">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 font-mono">
              Active Registry ({users.length})
            </h4>

            <div className="space-y-2 overflow-y-auto flex-1 pr-1" id="user-list-scroller">
              {users.map((u) => (
                <div 
                  key={u.id}
                  className="flex items-center justify-between p-3 bg-slate-50 border border-slate-100 rounded-xl hover:bg-slate-100/50 transition-colors"
                  id={`user-item-${u.id}`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-full ${u.avatarColor} flex items-center justify-center text-white font-bold text-xs ring-2 ring-white shadow-xs`}>
                      {getInitials(u.name)}
                    </div>
                    <div>
                      <h5 className="font-semibold text-slate-800 text-xs leading-none mb-1">{u.name}</h5>
                      <div className="flex items-center gap-1 text-[10px] text-slate-400 font-mono">
                        <Mail className="w-3 h-3 text-slate-300" />
                        <span className="truncate max-w-[120px]">{u.email}</span>
                        <span>•</span>
                        <span className="text-indigo-600 font-bold bg-indigo-50 px-1 py-0.2 rounded border border-indigo-100/50 text-[9px] uppercase tracking-wide">
                          {u.role}
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => onDeleteUser(u.id)}
                    aria-label={`Delete ${u.name}`}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                    id={`delete-user-${u.id}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}

              {users.length === 0 && (
                <div className="text-center py-12 text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200" id="users-empty">
                  <Users className="w-10 h-10 stroke-1 mx-auto text-slate-200 mb-1.5" />
                  <p className="text-xs font-sans">No team members enrolled.</p>
                </div>
              )}
            </div>
            
            <p className="text-[10px] text-slate-400 mt-4 leading-relaxed bg-amber-50 border border-amber-100 p-2.5 rounded-lg flex gap-2">
              <span className="font-bold flex-shrink-0 text-amber-600">Note:</span>
              <span>Deleting an enrolled user automatically clears their task assignments on the active sprint sheet while preserving audit logs.</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
